#include "tests.h"

int main() {
    TestMemory();
    TestBigChars();
    TestTerm();
    return 0;
}
