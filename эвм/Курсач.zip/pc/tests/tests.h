#ifndef TESTS_H
#define TESTS_H

#include <stdio.h>
#include <string.h>
#include "memory.h"
#include "bigChars.h"
#include "term.h"

int TestMemory(); 
int TestBigChars();
int TestTerm();

#endif
