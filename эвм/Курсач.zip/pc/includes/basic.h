#ifndef SCOMPUTER_BASIC_H
#define SCOMPUTER_BASIC_H

int basic_to_asm(const char* filename_bas, const char* filename_asm);

#endif //SCOMPUTER_BASIC_H