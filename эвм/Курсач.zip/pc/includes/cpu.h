#ifndef SCOMPUTER_CPU_H
#define SCOMPUTER_CPU_H

int cmd_search(const char* cmd);
int CU();

#endif //SCOMPUTER_CPU_H