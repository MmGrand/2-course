#ifndef PC_SIGNALS_H
#define PC_SIGNALS_H

void signalhangle(int signal);
void create_timer(double interval);

#endif //PC_SIGNALS_H
