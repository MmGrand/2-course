#ifndef SCOMPUTER_ASM_H
#define SCOMPUTER_ASM_H

int asm_to_object(const char* filename_asm, const char* filename_object);

#endif //SCOMPUTER_ASM_H
